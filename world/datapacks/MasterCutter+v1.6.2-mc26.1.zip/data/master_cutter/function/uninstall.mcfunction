# uninstall message
tellraw @a [{"text":"'"},{"text":"MasterCutter","color":"gray","italic":false},{"text":"'"},{"text":" Uninstalled.","color":"dark_green","italic":false}]

# disable the data pack
datapack disable "MasterCutter+v1.6.2-mc26.1.zip"
