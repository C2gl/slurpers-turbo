execute if score #set_once 777.odds matches 1.. run return 0

tellraw @a [{"color":"yellow","text":"Initialized "},{"color":"gold","text":"777 "},{"color":"yellow","text":"by "},{"color":"#6EDDFF","text":"p"},{"color":"#87CBFF","text":"h"},{"color":"#A0B9FF","text":"a"},{"color":"#B8A6FF","text":"i"},{"color":"#EA82FF","text":"c"}]
tellraw @a [{"bold":true,"color":"yellow","text":"Need the 777 resourcepack?\n\n"},{"bold":false,"color":"gray","text":"1. On "},{"bold":false,"click_event":{"action":"open_url","url":"https://modrinth.com/datapack/777/versions"},"color":"#1CAA59","hover_event":{"action":"show_text","value":[{"text":"Click to open 777 Modrinth Page!"}]},"text":"Modrinth","underlined":true},{"bold":false,"color":"gray","text":" go to the Versions tab and select the version of the datapack you are using\n2. Scroll to the bottom of the page and locate \"","underlined":false},{"bold":false,"color":"white","text":"777_rp_x.x.zip"},{"bold":false,"color":"gray","text":"\"\n3. Download the resourcepack .zip and install it. You should be good to go!\n\nFor further questions, you can also join my "},{"bold":false,"click_event":{"action":"open_url","url":"https://discord.gg/f5t3prrtRR"},"color":"blue","hover_event":{"action":"show_text","value":[{"text":"Click to join my Discord!"}]},"text":"Discord","underlined":true}]

scoreboard players set #set_once 777.odds 1
scoreboard players set #low_odd 777.odds 160
scoreboard players set #mid_odd 777.odds 80
scoreboard players set #high_odd 777.odds 40