tag @s add placed
setblock ~ ~ ~ minecraft:deepslate_brick_wall
setblock ~ ~1 ~ minecraft:barrier
summon interaction ~ ~1 ~ {width:1.1f,height:1.1f,Tags:["slot_machine"]}
tp @s ~ ~1 ~
execute facing entity @p eyes rotated ~ 0 run function animated_java:slot_machine/summon {args:{}}
execute as @n[type=item_display,tag=aj.slot_machine.root] positioned 0. 0 0. rotated ~45 0 positioned ^ ^ ^-.5 align xz facing -.5 0 -.5 rotated ~-45 0 run rotate @s ~ ~