execute store result storage 777:odds input.low int 1 run scoreboard players get #low_odd 777.odds
execute store result storage 777:odds input.mid int 1 run scoreboard players get #mid_odd 777.odds
execute store result storage 777:odds input.high int 1 run scoreboard players get #high_odd 777.odds