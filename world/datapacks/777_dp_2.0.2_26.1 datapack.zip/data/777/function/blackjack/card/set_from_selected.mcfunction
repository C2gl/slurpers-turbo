tag @e remove 777.dealt_card_temp
tag @s add 777.dealt_card_temp
execute as @e[tag=777.blackjack_entity,tag=777.blackjack.bet] if score @s 777.real_ID = @n[tag=777.dealt_card_temp] 777.real_ID if score @s 777.blackjack.group = @n[tag=777.dealt_card_temp] 777.blackjack.group unless entity @s[tag=777.has_bet] run return run function 777:blackjack/card/no_bet_here

execute as @n[tag=777.dealer_temp] at @s facing entity @n[tag=777.dealt_card_temp] feet run rotate @s ~ ~60
tag @s remove 777.dealt_card_temp

execute if score #has_no_bet 777.math_temp matches 1.. run return 0

# $say i was dealt $(selected_card)
particle minecraft:electric_spark ^ ^0.08 ^ 0.025 0.05 0.025 0.05 3
#particle minecraft:white_smoke ^ ^0.08 ^ 0 0 0 0.025 3
playsound minecraft:block.moss.step player @a ~ ~ ~ 1 1.5
$data modify entity @s text set value "$(selected_card)"
$data modify entity @s data.selected_card set value "$(selected_card)"

function 777:blackjack/card/flip_animation with entity @s data

function 777:blackjack/card/set_value

execute if entity @s[tag=777.blackjack.dealer_card_slot,tag=777.blackjack.card_slot2] run data modify entity @s text set value "?"

#$tellraw @a[distance=..2.25] [{"color":"yellow","text":"Card Dealt: "},{"bold":true,"color":"gold","text":"$(selected_card)"}]
tellraw @a[distance=..2.25] [{"color":"yellow","text":"Card Dealt: "},{"bold":true,"color":"gold","entity":"@s","nbt":"text"}]