execute if data entity @s {text:"2"} run scoreboard players set @s 777.blackjack.card_value 2
execute if data entity @s {text:"3"} run scoreboard players set @s 777.blackjack.card_value 3
execute if data entity @s {text:"4"} run scoreboard players set @s 777.blackjack.card_value 4
execute if data entity @s {text:"5"} run scoreboard players set @s 777.blackjack.card_value 5
execute if data entity @s {text:"6"} run scoreboard players set @s 777.blackjack.card_value 6
execute if data entity @s {text:"7"} run scoreboard players set @s 777.blackjack.card_value 7
execute if data entity @s {text:"8"} run scoreboard players set @s 777.blackjack.card_value 8
execute if data entity @s {text:"9"} run scoreboard players set @s 777.blackjack.card_value 9
execute if data entity @s {text:"10"} run scoreboard players set @s 777.blackjack.card_value 10
execute if data entity @s {text:"J"} run scoreboard players set @s 777.blackjack.card_value 10
execute if data entity @s {text:"Q"} run scoreboard players set @s 777.blackjack.card_value 10
execute if data entity @s {text:"K"} run scoreboard players set @s 777.blackjack.card_value 10
execute if data entity @s {text:"♠"} run scoreboard players set @s 777.blackjack.card_value -1

function 777:blackjack/click/execute_as_type_in_group_no_tag {type: "bet", cmd: "function 777:blackjack/bet/get_hand_value"}

function 777:blackjack/click/execute_as_type_in_group_no_tag {type: "dealer", cmd: "function 777:blackjack/dealer/get_hand_value"}