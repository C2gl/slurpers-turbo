data merge entity @s {item:{id:"minecraft:barrier",count:1,components:{"minecraft:item_model":"777:invisible"}}}
particle minecraft:witch ~ ~0.2 ~ 0 0 0 10 4
playsound minecraft:block.trial_spawner.spawn_item hostile @a ~ ~ ~ 0.5 1.5

function 777:blackjack/dealer/chat/lose