tag @s remove 777.dealing

execute at @s positioned 0. 0 0. rotated ~45 0 positioned ^ ^ ^-.5 align xz facing -.5 0 -.5 rotated ~-45 0 run rotate @s ~ ~
# say stopped dealing