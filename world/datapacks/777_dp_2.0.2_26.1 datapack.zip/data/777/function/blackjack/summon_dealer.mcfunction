execute store result score #random 777.math_temp run random value -1000..1300

# scoreboard players set #random 777.math_temp 1051

execute store result score #profession 777.math_temp run random value 1..15
execute if score #profession 777.math_temp matches 1 run data modify storage 777:blackjack profession set value "none"
execute if score #profession 777.math_temp matches 2 run data modify storage 777:blackjack profession set value "armorer"
execute if score #profession 777.math_temp matches 3 run data modify storage 777:blackjack profession set value "butcher"
execute if score #profession 777.math_temp matches 4 run data modify storage 777:blackjack profession set value "cartographer"
execute if score #profession 777.math_temp matches 5 run data modify storage 777:blackjack profession set value "cleric"
execute if score #profession 777.math_temp matches 6 run data modify storage 777:blackjack profession set value "farmer"
execute if score #profession 777.math_temp matches 7 run data modify storage 777:blackjack profession set value "fisherman"
execute if score #profession 777.math_temp matches 8 run data modify storage 777:blackjack profession set value "fletcher"
execute if score #profession 777.math_temp matches 9 run data modify storage 777:blackjack profession set value "leatherworker"
execute if score #profession 777.math_temp matches 10 run data modify storage 777:blackjack profession set value "librarian"
execute if score #profession 777.math_temp matches 11 run data modify storage 777:blackjack profession set value "mason"
execute if score #profession 777.math_temp matches 12 run data modify storage 777:blackjack profession set value "nitwit"
execute if score #profession 777.math_temp matches 13 run data modify storage 777:blackjack profession set value "shepherd"
execute if score #profession 777.math_temp matches 14 run data modify storage 777:blackjack profession set value "toolsmith"
execute if score #profession 777.math_temp matches 15 run data modify storage 777:blackjack profession set value "weaponsmith"

execute if score #random 777.math_temp matches -1000..500 run summon mannequin ^ ^ ^-1 {Invulnerable:1b,immovable:true,hide_description:true,Tags:["777.blackjack_entity","777.dealer","new","777.blackjack.dealer"],CustomName:"The Dealer",profile:{"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYTA3NDA2MTFhNjUyZWJlOTZkYjE1MmE5ZGE4Y2FlOTQ0YTY5NjEzNzQzNzBmOGIzZDJjYjU3NjExNzc1OTE3ZiJ9fX0="}]}}
execute if score #random 777.math_temp matches 501..600 run summon mannequin ^ ^ ^-1 {Invulnerable:1b,immovable:true,hide_description:true,Tags:["777.blackjack_entity","777.dealer","new","777.blackjack.dealer"],CustomName:"The Dealer",profile:{"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOGI2MWQ5NTE2MDY2Y2JkOTk0ZDgwNzZmZGUwMTI1YTk3YTcxNTM1Mzg1YzgxODc2YWIwZjRiZmEzZDRlNDQ5ZCJ9fX0="}]}}
execute if score #random 777.math_temp matches 601..700 run summon mannequin ^ ^ ^-1 {Invulnerable:1b,immovable:true,hide_description:true,Tags:["777.blackjack_entity","777.dealer","new","777.blackjack.dealer"],CustomName:"The Dealer",profile:{"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZTdhZmI5OTcxNGQxYjBkYzdiZGFkOGE2ODVhYzRlYzk1YzAyNjBkMTkzM2I3ZGM2NDEwMWZiNDEzNDQ5NGJjMyJ9fX0="}]}}
execute if score #random 777.math_temp matches 701..800 run summon mannequin ^ ^ ^-1 {Invulnerable:1b,immovable:true,hide_description:true,Tags:["777.blackjack_entity","777.dealer","new","777.blackjack.dealer"],CustomName:"The Dealer",profile:{"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzFhMjI2NGFjODNjZTE4YmFhY2ViZjY4NmM5ZjU2YzdkODVmN2YyMzNiZjhhMDQ4Mzk1ZGM1NmVkN2Q5MjZjYSJ9fX0="}]}}
execute if score #random 777.math_temp matches 801..900 run summon mannequin ^ ^ ^-1 {Invulnerable:1b,immovable:true,hide_description:true,Tags:["777.blackjack_entity","777.dealer","new","777.blackjack.dealer"],CustomName:"The Dealer",profile:{"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYWIxMzI4ZGJkNTEwN2VmNjBlMzk2NTc3ZGVhNzQ4ZGQzZDIwNjcwZmMwNjY3MWUzOTc3Njg4MDRlZDBlNjVlMSJ9fX0="}]}}
execute if score #random 777.math_temp matches 901..1000 run summon mannequin ^ ^ ^-1 {Invulnerable:1b,immovable:true,hide_description:true,Tags:["777.blackjack_entity","777.dealer","new","777.blackjack.dealer"],CustomName:"The Dealer",profile:{"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYWIxMzI4ZGJkNTEwN2VmNjBlMzk2NTc3ZGVhNzQ4ZGQzZDIwNjcwZmMwNjY3MWUzOTc3Njg4MDRlZDBlNjVlMSJ9fX0="}]}}
execute if score #random 777.math_temp matches 1001..1220 run function 777:blackjack/summon_villager with storage 777:blackjack
execute if score #random 777.math_temp matches 1221..1300 run summon mannequin ^ ^ ^-1 {Invulnerable:1b,immovable:true,hide_description:true,Tags:["777.blackjack_entity","777.dealer","new","777.blackjack.dealer"],CustomName:"The Dealer",profile:"phaic"}