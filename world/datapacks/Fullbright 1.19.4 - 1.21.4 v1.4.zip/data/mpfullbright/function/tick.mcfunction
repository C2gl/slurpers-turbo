# main 

execute unless score FBDisabledByDefault mpfb.config matches 1 as @a[tag=!mpfb.fullbrightoff] run effect give @s minecraft:night_vision 11 1 true
execute unless score FBDisabledByDefault mpfb.config matches 1 as @a[tag=mpfb.fullbrightoff] run effect clear @s minecraft:night_vision

execute if score FBDisabledByDefault mpfb.config matches 1 as @a[tag=mpfb.fullbrightoff] run effect give @s minecraft:night_vision 11 1 true
execute if score FBDisabledByDefault mpfb.config matches 1 as @a[tag=!mpfb.fullbrightoff] run effect clear @s minecraft:night_vision


# toggle

execute as @a if score @s ToggleFullBright matches 1.. run function mpfullbright:toggle


# blacklist

scoreboard players enable @a[tag=!FB_blacklisted] ToggleFullBright
scoreboard players reset @a[tag=FB_blacklisted] ToggleFullBright
execute as @a[tag=FB_blacklisted] run effect clear @s minecraft:night_vision
