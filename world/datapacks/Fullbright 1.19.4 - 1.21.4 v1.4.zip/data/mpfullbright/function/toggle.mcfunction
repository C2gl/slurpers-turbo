execute store success score @s mpfb.success run execute if entity @s[tag=mpfb.fullbrightoff]

# toggle

execute unless score @s mpfb.success matches 1 run tag @s add mpfb.fullbrightoff
execute if score @s mpfb.success matches 1 run tag @s remove mpfb.fullbrightoff


# message/sound: default enabled
execute unless score @s mpfb.success matches 1 unless score FBDisabledByDefault mpfb.config matches 1 run tellraw @s ["",{"text":"\ud83c\udf19","color":"yellow"},{"text":" Fullbright Disabled!","color":"red"}]
execute unless score @s mpfb.success matches 1 at @s unless score FBDisabledByDefault mpfb.config matches 1 run playsound minecraft:block.copper_bulb.turn_off master @s ~ ~ ~

execute if score @s mpfb.success matches 1 unless score FBDisabledByDefault mpfb.config matches 1 run tellraw @s ["",{"text":"\u2600","color":"yellow"},{"text":" Fullbright Enabled!","color":"green"}]
execute if score @s mpfb.success matches 1 at @s unless score FBDisabledByDefault mpfb.config matches 1 run playsound minecraft:block.copper_bulb.turn_on master @s ~ ~ ~

# message/sound: default disabled
execute if score @s mpfb.success matches 1 if score FBDisabledByDefault mpfb.config matches 1 run tellraw @s ["",{"text":"\ud83c\udf19","color":"yellow"},{"text":" Fullbright Disabled!","color":"red"}]
execute if score @s mpfb.success matches 1 at @s if score FBDisabledByDefault mpfb.config matches 1 run playsound minecraft:block.copper_bulb.turn_off master @s ~ ~ ~

execute unless score @s mpfb.success matches 1 if score FBDisabledByDefault mpfb.config matches 1 run tellraw @s ["",{"text":"\u2600","color":"yellow"},{"text":" Fullbright Enabled!","color":"green"}]
execute unless score @s mpfb.success matches 1 at @s if score FBDisabledByDefault mpfb.config matches 1 run playsound minecraft:block.copper_bulb.turn_on master @s ~ ~ ~


scoreboard players reset @s ToggleFullBright
