scoreboard objectives add mpfb.success dummy
scoreboard objectives add mpfb.config dummy
scoreboard objectives add ToggleFullBright trigger

# /scoreboard players set FBDisabledByDefault mpfb.config <1/0> 
# to enable or disable fullbright by default (1: true, 0: false)

# /tag player <add/remove> FB_blacklisted
# to blacklist, unblacklist a player