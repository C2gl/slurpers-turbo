scoreboard objectives remove mpfb.success
scoreboard objectives remove mpfb.config
scoreboard objectives remove ToggleFullBright
effect clear @a minecraft:night_vision